package com.cg.capstore.bean;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="capstore.mycart")
public class MyCart
{
	@Id
	@Column(name="cartId")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int cartId;
	@OneToMany(cascade=CascadeType.ALL,mappedBy="cart")
	private Map<Long,Integer> order =new HashMap<>();
	
	public MyCart() 
	{
		super();
	}
	
	public MyCart(int cartId, Map<Long, Integer> order) 
	{
		super();
		this.cartId = cartId;
		this.order = order;
	}
	
	public int getCartId() 
	{
		return cartId;
	}
	public void setCartId(int cartId) 
	{
		this.cartId = cartId;
	}
	
	public Map<Long, Integer> getOrder() 
	{
		return order;
	}

	public void setOrder(Map<Long, Integer> order) 
	{
		this.order = order;
	}

	@Override
	public String toString() 
	{
		return "MyCart [cartId=" + cartId + ", productId_Quantity=" + order + "]";
	}
	
	
	
}
